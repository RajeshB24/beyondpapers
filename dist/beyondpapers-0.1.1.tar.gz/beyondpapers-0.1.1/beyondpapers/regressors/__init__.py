from .__base_regressor import GradientDescentRegressor
from .__tensorflow_regressor import tensorflow_AnnRegressor


__all__=["GradientDescentRegressor","tensorflow_AnnRegressor"]
